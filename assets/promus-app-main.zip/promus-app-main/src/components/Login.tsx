import React from 'react';

function Login() {
  console.log('Login.render');

  return <div className="container">#login</div>;
}

export default Login;
