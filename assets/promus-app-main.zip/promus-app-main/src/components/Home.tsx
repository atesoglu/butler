import React, { Fragment } from 'react';

function Home() {
  return (
    <Fragment>
      <h1>Home</h1>
    </Fragment>
  );
}

export default Home;
